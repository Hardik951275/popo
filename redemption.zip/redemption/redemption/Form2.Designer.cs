﻿using System.Windows.Forms;

namespace redemption
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem stockToolStripMenuItem;
        private ToolStripMenuItem campsToolStripMenuItem;
        private ToolStripMenuItem profileToolStripMenuItem;
        private Button logout;
        private ToolStripMenuItem homeToolStripMenuItem;

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.campsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logout = new System.Windows.Forms.Button();
            this.addDonorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deletDonorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDonorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCollectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Black", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.collectToolStripMenuItem,
            this.homeToolStripMenuItem,
            this.stockToolStripMenuItem,
            this.campsToolStripMenuItem,
            this.profileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(154, 791);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDonorToolStripMenuItem,
            this.deletDonorToolStripMenuItem,
            this.updateDonorToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.fileToolStripMenuItem.Text = "file";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.homeToolStripMenuItem.Text = "Home";
            // 
            // stockToolStripMenuItem
            // 
            this.stockToolStripMenuItem.Name = "stockToolStripMenuItem";
            this.stockToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.stockToolStripMenuItem.Text = "stock";
            this.stockToolStripMenuItem.Click += new System.EventHandler(this.stockToolStripMenuItem_Click);
            // 
            // campsToolStripMenuItem
            // 
            this.campsToolStripMenuItem.Name = "campsToolStripMenuItem";
            this.campsToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.campsToolStripMenuItem.Text = "camps";
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.profileToolStripMenuItem.Text = "profile";
            // 
            // logout
            // 
            this.logout.Dock = System.Windows.Forms.DockStyle.Right;
            this.logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.Location = new System.Drawing.Point(1124, 0);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(50, 791);
            this.logout.TabIndex = 1;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.UseWaitCursor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // addDonorToolStripMenuItem
            // 
            this.addDonorToolStripMenuItem.Name = "addDonorToolStripMenuItem";
            this.addDonorToolStripMenuItem.Size = new System.Drawing.Size(343, 52);
            this.addDonorToolStripMenuItem.Text = "add donor";
            // 
            // deletDonorToolStripMenuItem
            // 
            this.deletDonorToolStripMenuItem.Name = "deletDonorToolStripMenuItem";
            this.deletDonorToolStripMenuItem.Size = new System.Drawing.Size(343, 52);
            this.deletDonorToolStripMenuItem.Text = "Delet Donor";
            // 
            // updateDonorToolStripMenuItem
            // 
            this.updateDonorToolStripMenuItem.Name = "updateDonorToolStripMenuItem";
            this.updateDonorToolStripMenuItem.Size = new System.Drawing.Size(343, 52);
            this.updateDonorToolStripMenuItem.Text = "Update Donor";
            // 
            // collectToolStripMenuItem
            // 
            this.collectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCollectionToolStripMenuItem});
            this.collectToolStripMenuItem.Name = "collectToolStripMenuItem";
            this.collectToolStripMenuItem.Size = new System.Drawing.Size(141, 51);
            this.collectToolStripMenuItem.Text = "collect";
            // 
            // addCollectionToolStripMenuItem
            // 
            this.addCollectionToolStripMenuItem.Name = "addCollectionToolStripMenuItem";
            this.addCollectionToolStripMenuItem.Size = new System.Drawing.Size(358, 52);
            this.addCollectionToolStripMenuItem.Text = "Add collection ";
            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(1174, 791);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Redemption";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private ToolStripMenuItem addDonorToolStripMenuItem;
        private ToolStripMenuItem deletDonorToolStripMenuItem;
        private ToolStripMenuItem updateDonorToolStripMenuItem;
        private ToolStripMenuItem collectToolStripMenuItem;
        private ToolStripMenuItem addCollectionToolStripMenuItem;
    }
}