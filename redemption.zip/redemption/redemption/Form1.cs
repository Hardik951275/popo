﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace redemption
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //C1.con.Open();

        }
        

        private void button1_Click(object sender, EventArgs e)
        {

            if(textBox1.Text!="" & textBox2.Text!="")
            {
                //1.con.Open();
               string sql ="select * from login where usn='"+textBox1.Text+"' and psw='"+textBox2.Text+"'";
                SqlDataAdapter da = new SqlDataAdapter(sql,C1.con);
                DataTable dt= new DataTable();
                da.Fill(dt);
               if(dt.Rows.Count>0 )
                {
                    Form2 f = new Form2();
                    f.Show();
                    this.Hide();
                }

            }
            else
            {
                MessageBox.Show("check username and paaword");
            }
        }
    }
}
