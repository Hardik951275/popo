﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace redemption
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Form1 f= new Form1();
            f.Show();
            this.Hide();    
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 f= new Form3();   
            f.Show(); this.Hide();
        }
    }
}
